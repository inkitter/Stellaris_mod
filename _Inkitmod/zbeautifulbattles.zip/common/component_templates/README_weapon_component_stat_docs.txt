##
##
##
##
## When saving the weapon_components.ods file as .csv, the field delimiter option should be ;
## and the text delimiter option set to none/cleared
##
##