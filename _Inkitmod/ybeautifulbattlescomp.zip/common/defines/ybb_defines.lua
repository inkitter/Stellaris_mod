
NDefines.NGameplay.NAVY_SIZE_BASE = 10 -- 5 Base value of Naval Capacity