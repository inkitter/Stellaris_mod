-- NAI
--NDefines.NAI.SECTOR_NAVY_BUDGET_FRACTION = 0.50 -- Fraction of budget going to spaceships Default 0.00
NDefines.NAI.SECTOR_STATION_BUDGET_FRACTION = 0.20	-- Fraction of budget going to stations Default 0.20
NDefines.NAI.SECTOR_BUILDING_BUDGET_FRACTION = 0.10 -- Fraction of budget going to buildings Default 0.40
NDefines.NAI.SECTOR_SPACEPORT_BUDGET_FRACTION = 0.20-- Fraction of budget going to spaceports Default 0.30
NDefines.NAI.SECTOR_ARMY_BUDGET_FRACTION = 0.00	-- Fraction of budget going to army Default 0.10

--NDefines.NAI.SECTOR_NAVY_BUDGET_FRACTION = 0.40 -- Fraction of maintenance budget going to spaceships Default 0.00
NDefines.NAI.SECTOR_BUILDING_MAINT_BUDGET_FRACTION = 0.50 -- Fraction of maintenance budget going to buildings Default 0.50
NDefines.NAI.SECTOR_STATION_MAINT_BUDGET_FRACTION = 0.10-- Fraction of maintenance budget going to spaceports and stations Default 0.40
NDefines.NAI.SECTOR_ARMY_MAINT_BUDGET_FRACTION = 0.00	-- Fraction of maintenance budget going to army Default 0.10